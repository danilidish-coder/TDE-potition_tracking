@echo off
setlocal
cd /d "%~dp0"
echo ===============================================
echo   BUILD - KATAGRAFH THESEON MODERN
 echo ===============================================
py -m pip install --upgrade pip
if errorlevel 1 goto :err
py -m pip install -r requirements.txt
if errorlevel 1 goto :err
py -m PyInstaller --noconfirm --clean --windowed --onedir --name "Καταγραφή Θέσεων" position_tracking_FINAL.py
if errorlevel 1 goto :err
echo.
echo BUILD OK
echo EXE: dist\Καταγραφή Θέσεων\Καταγραφή Θέσεων.exe
pause
exit /b 0
:err
echo.
echo BUILD FAILED - κρατηστε το μηνυμα λαθους.
pause
exit /b 1
