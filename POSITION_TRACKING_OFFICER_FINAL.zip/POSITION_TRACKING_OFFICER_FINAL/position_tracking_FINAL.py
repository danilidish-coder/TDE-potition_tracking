from __future__ import annotations

import json
import os
import hashlib
import shutil
import re
import socket
import sys
import tempfile
import time
import uuid
import zipfile
import unicodedata
from contextlib import contextmanager
from dataclasses import dataclass, asdict
from datetime import datetime, date, timedelta, time as dtime
from pathlib import Path
from xml.etree import ElementTree as ET

APP_NAME = "TDE Krystallopigis - Katagrafi Theseon"
SETTINGS_NAME = "position_tracking.settings.json"
DEFAULT_CUTOFF = "10:00"


def _clean(value: object) -> str:
    return " ".join(str(value or "").strip().split())


def _safe_name(value: str) -> str:
    v = re.sub(r"[^0-9A-Za-zΑ-Ωα-ω_-]+", "_", _clean(value))
    return v or "UNKNOWN"


def _exe_dir() -> Path:
    try:
        return Path(sys.executable).resolve().parent
    except Exception:
        return Path.cwd()


def _fallback_settings_path() -> Path:
    public = os.environ.get("PUBLIC")
    if public:
        return Path(public) / "Documents" / "TDE_Krystallopigis" / SETTINGS_NAME
    appdata = os.environ.get("APPDATA") or str(Path.home())
    return Path(appdata) / "TDE_Krystallopigis" / SETTINGS_NAME


def _settings_path() -> Path:
    local = _exe_dir() / SETTINGS_NAME
    if local.exists():
        return local
    try:
        local.parent.mkdir(parents=True, exist_ok=True)
        test = local.parent / f".write_test_{uuid.uuid4().hex}.tmp"
        test.write_text("ok", encoding="utf-8")
        test.unlink(missing_ok=True)
        return local
    except Exception:
        return _fallback_settings_path()


@dataclass
class AppConfig:
    central_root: str = ""
    personnel_file: str = ""
    cutoff: str = DEFAULT_CUTOFF
    positions: list[str] | None = None
    admin_pin_hash: str = ""

    def __post_init__(self):
        booth_positions = [str(i) for i in range(1, 15)]
        if self.positions is None:
            self.positions = booth_positions
        else:
            cleaned = [_clean(x) for x in self.positions if _clean(x)]
            for pos in booth_positions:
                if pos not in cleaned:
                    cleaned.append(pos)
            self.positions = cleaned

    @classmethod
    def load(cls) -> "AppConfig":
        path = _settings_path()
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return cls(
                central_root=_clean(data.get("central_root")),
                personnel_file=_clean(data.get("personnel_file")),
                cutoff=_clean(data.get("cutoff")) or DEFAULT_CUTOFF,
                positions=[_clean(x) for x in data.get("positions", []) if _clean(x)] or None,
                admin_pin_hash=_clean(data.get("admin_pin_hash")),
            )
        except Exception:
            return cls()

    def save(self) -> Path:
        path = _settings_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_suffix(path.suffix + ".tmp")
        temp.write_text(json.dumps(asdict(self), ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(temp, path)
        return path


@dataclass(frozen=True)
class PersonnelRecord:
    agms: str
    rank: str
    surname: str
    given_name: str

    @property
    def full_name(self) -> str:
        return _clean(f"{self.surname} {self.given_name}")

    @property
    def display(self) -> str:
        return _clean(f"{self.agms} - {self.rank} {self.full_name}")


class PersonnelRepository:
    NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
    REL = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"

    AGMS_ALIASES = {
        "ΑΓΜΣ", "AΓΜΣ", "AGMS", "ΑΓΜ", "AΓΜ", "ΑΡΙΘΜΟΣΜΗΤΡΩΟΥ",
        "ΑΡΙΘΜΗΤΡΩΟΥ", "ΜΗΤΡΩΟ", "ΑΡΜΗΤΡΩΟΥ", "ΑΡΙΘΜΟΣΜΗΤΡ",
    }
    RANK_ALIASES = {"ΒΑΘΜΟΣ", "ΒΑΘΜ", "RANK"}
    SURNAME_ALIASES = {"ΕΠΩΝΥΜΟ", "ΕΠΩΝ", "SURNAME", "LASTNAME"}
    GIVEN_ALIASES = {"ΟΝΟΜΑ", "FIRSTNAME", "GIVENNAME"}
    FULLNAME_ALIASES = {"ΟΝΟΜΑΤΕΠΩΝΥΜΟ", "ΟΝΟΜΑΕΠΩΝΥΜΟ", "FULLNAME"}

    @staticmethod
    def _col_index(ref: str) -> int:
        m = re.match(r"([A-Z]+)", ref.upper())
        if not m:
            return 0
        n = 0
        for ch in m.group(1):
            n = n * 26 + ord(ch) - 64
        return n - 1

    @staticmethod
    def _header_key(value: object) -> str:
        raw = _clean(value).upper()
        raw = "".join(ch for ch in unicodedata.normalize("NFD", raw) if unicodedata.category(ch) != "Mn")
        return re.sub(r"[^0-9A-ZΑ-Ω]", "", raw)

    @staticmethod
    def _normalize_agms(value: object) -> str:
        s = _clean(value)
        if re.fullmatch(r"\d+\.0+", s):
            s = s.split(".", 1)[0]
        s = re.sub(r"\s+", "", s)
        return s

    @classmethod
    def _looks_like_agms(cls, value: object) -> bool:
        s = cls._normalize_agms(value)
        return bool(re.fullmatch(r"\d{4,12}", s))

    @classmethod
    def _read_sheets(cls, path: str | Path) -> list[list[dict[int, str]]]:
        p = Path(path)
        if not p.is_file():
            raise ValueError("Δεν βρέθηκε το αρχείο Excel.")
        if p.suffix.lower() not in {".xlsx", ".xlsm"}:
            raise ValueError("Υποστηρίζονται αρχεία Excel .xlsx ή .xlsm.")
        try:
            with zipfile.ZipFile(p, "r") as z:
                shared: list[str] = []
                if "xl/sharedStrings.xml" in z.namelist():
                    root = ET.fromstring(z.read("xl/sharedStrings.xml"))
                    for si in root.findall(f"{cls.NS}si"):
                        shared.append("".join((t.text or "") for t in si.iter(f"{cls.NS}t")))

                wb = ET.fromstring(z.read("xl/workbook.xml"))
                rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
                targets = {r.attrib.get("Id"): r.attrib.get("Target") for r in rels}
                sheets_el = wb.find(f"{cls.NS}sheets")
                if sheets_el is None or len(sheets_el) == 0:
                    raise ValueError("Το Excel δεν έχει φύλλο.")

                all_sheets: list[list[dict[int, str]]] = []
                for sheet in sheets_el:
                    rid = sheet.attrib.get(f"{cls.REL}id")
                    target = (targets.get(rid) or "worksheets/sheet1.xml").lstrip("/")
                    if not target.startswith("xl/"):
                        target = "xl/" + target
                    if target not in z.namelist():
                        continue
                    root = ET.fromstring(z.read(target))
                    rows: list[dict[int, str]] = []
                    for row in root.findall(f".//{cls.NS}row"):
                        cells: dict[int, str] = {}
                        for c in row.findall(f"{cls.NS}c"):
                            idx = cls._col_index(c.attrib.get("r", "A1"))
                            t = c.attrib.get("t")
                            if t == "inlineStr":
                                value = "".join((x.text or "") for x in c.iter(f"{cls.NS}t"))
                            else:
                                v = c.find(f"{cls.NS}v")
                                raw = "" if v is None else (v.text or "")
                                value = shared[int(raw)] if t == "s" and raw.isdigit() and int(raw) < len(shared) else raw
                            cells[idx] = _clean(value)
                        if cells:
                            rows.append(cells)
                    if rows:
                        all_sheets.append(rows)
                if not all_sheets:
                    raise ValueError("Το Excel είναι κενό.")
                return all_sheets
        except (zipfile.BadZipFile, KeyError, ET.ParseError) as exc:
            raise ValueError(f"Μη έγκυρο Excel: {exc}") from exc

    @classmethod
    def _header_col(cls, row: dict[int, str], aliases: set[str], fuzzy: str = "") -> int:
        for i, value in row.items():
            key = cls._header_key(value)
            if key in aliases:
                return i
            if fuzzy and fuzzy in key:
                return i
        return -1

    @classmethod
    def _find_personnel_layout(cls, rows: list[dict[int, str]]) -> tuple[int, dict[str, int]] | None:
        best = None
        best_score = -1
        for ridx, row in enumerate(rows[:12]):
            i_agms = cls._header_col(row, cls.AGMS_ALIASES)
            if i_agms < 0:
                for i, value in row.items():
                    key = cls._header_key(value)
                    if "ΑΓΜΣ" in key or "AGMS" in key or ("ΜΗΤΡΩ" in key and ("ΑΡΙΘ" in key or key == "ΜΗΤΡΩΟ")):
                        i_agms = i; break
            if i_agms < 0:
                continue
            i_full = cls._header_col(row, cls.FULLNAME_ALIASES, "ΟΝΟΜΑΤΕΠΩΝΥΜ")
            i_sur = cls._header_col(row, cls.SURNAME_ALIASES, "ΕΠΩΝ")
            i_given = cls._header_col(row, cls.GIVEN_ALIASES)
            if i_sur == i_full:
                i_sur = -1
            if i_given == i_full:
                i_given = -1
            layout = {
                "agms": i_agms,
                "rank": cls._header_col(row, cls.RANK_ALIASES, "ΒΑΘΜ"),
                "surname": i_sur,
                "given": i_given,
                "full": i_full,
            }
            score = 10 + sum(1 for k, v in layout.items() if k != "agms" and v >= 0)
            if score > best_score:
                best = (ridx, layout); best_score = score
        return best

    @classmethod
    def _infer_agms_col(cls, rows: list[dict[int, str]], known_agms: set[str] | None = None) -> int:
        known = {cls._normalize_agms(x) for x in (known_agms or set()) if cls._normalize_agms(x)}
        cols = sorted({c for row in rows[:100] for c in row})
        best_col, best_score = -1, -1.0
        for col in cols:
            vals = [cls._normalize_agms(row.get(col, "")) for row in rows[:100] if _clean(row.get(col, ""))]
            if not vals:
                continue
            matches = sum(1 for v in vals if v in known) if known else 0
            plausible = sum(1 for v in vals if cls._looks_like_agms(v))
            uniq = len(set(vals))
            score = matches * 1000 + plausible * 10 + uniq - max(0, len(vals) - plausible) * 2
            if plausible and score > best_score:
                best_col, best_score = col, score
        return best_col

    @classmethod
    def load(cls, path: str | Path) -> tuple[PersonnelRecord, ...]:
        sheets = cls._read_sheets(path)
        best_records: list[PersonnelRecord] = []
        for rows in sheets:
            layout_info = cls._find_personnel_layout(rows)
            if layout_info:
                header_row, layout = layout_info
                data_rows = rows[header_row + 1:]
            else:
                i_agms = cls._infer_agms_col(rows)
                if i_agms < 0:
                    continue
                header_row = -1
                layout = {"agms": i_agms, "rank": -1, "surname": -1, "given": -1, "full": -1}
                data_rows = rows

            merged: dict[str, PersonnelRecord] = {}
            order: list[str] = []
            for row in data_rows:
                def cell(i: int) -> str:
                    return _clean(row.get(i, "")) if i >= 0 else ""
                agms = cls._normalize_agms(cell(layout["agms"]))
                if not agms or not cls._looks_like_agms(agms):
                    continue
                rank = cell(layout["rank"])
                surname = cell(layout["surname"])
                given = cell(layout["given"])
                full = cell(layout["full"])
                if full and not surname and not given:
                    parts = full.split()
                    surname = parts[0] if parts else full
                    given = " ".join(parts[1:]) if len(parts) > 1 else ""
                rec = PersonnelRecord(agms, rank, surname, given)
                if agms not in merged:
                    merged[agms] = rec; order.append(agms)
                else:
                    old = merged[agms]
                    merged[agms] = PersonnelRecord(
                        agms,
                        old.rank or rec.rank,
                        old.surname or rec.surname,
                        old.given_name or rec.given_name,
                    )
            records = [merged[a] for a in order]
            if len(records) > len(best_records):
                best_records = records

        if not best_records:
            raise ValueError("Δεν εντοπίστηκε κανένας έγκυρος Α.Γ.Μ.Σ. στο Excel. Ελέγξτε μόνο ότι το αρχείο περιέχει αριθμούς μητρώου.")
        return tuple(best_records)


class ShiftRosterRepository:
    @classmethod
    def load_agms(cls, path: str | Path, known_agms: set[str] | list[str] | tuple[str, ...] | None = None) -> tuple[str, ...]:
        sheets = PersonnelRepository._read_sheets(path)
        known = {PersonnelRepository._normalize_agms(x) for x in (known_agms or []) if PersonnelRepository._normalize_agms(x)}
        best_values: list[str] = []
        best_score = -1

        for rows in sheets:
            agms_col = -1
            header_row = -1
            for ridx, row in enumerate(rows[:12]):
                col = PersonnelRepository._header_col(row, PersonnelRepository.AGMS_ALIASES)
                if col < 0:
                    for i, value in row.items():
                        key = PersonnelRepository._header_key(value)
                        if "ΑΓΜΣ" in key or "AGMS" in key or ("ΜΗΤΡΩ" in key and ("ΑΡΙΘ" in key or key == "ΜΗΤΡΩΟ")):
                            col = i; break
                if col >= 0:
                    agms_col = col; header_row = ridx; break

            if agms_col < 0 and known:
                cols = sorted({c for row in rows for c in row})
                matches_per_col = []
                for col in cols:
                    matches = sum(1 for row in rows if PersonnelRepository._normalize_agms(row.get(col, "")) in known)
                    matches_per_col.append((matches, col))
                matches_per_col.sort(reverse=True)
                if matches_per_col and matches_per_col[0][0] > 0:
                    agms_col = matches_per_col[0][1]

            if agms_col < 0:
                agms_col = PersonnelRepository._infer_agms_col(rows, known)
            if agms_col < 0:
                continue

            data_rows = rows[header_row + 1:] if header_row >= 0 else rows
            values: list[str] = []
            seen: set[str] = set()
            known_hits = 0
            for row in data_rows:
                value = PersonnelRepository._normalize_agms(row.get(agms_col, ""))
                if not value or not PersonnelRepository._looks_like_agms(value):
                    continue
                if value not in seen:
                    seen.add(value); values.append(value)
                    if value in known:
                        known_hits += 1
            score = len(values) + known_hits * 100
            if values and score > best_score:
                best_values = values; best_score = score

        if not best_values:
            raise ValueError("Δεν εντοπίστηκε κανένας έγκυρος Α.Γ.Μ.Σ. στο Excel βάρδιας. Το αρχείο μπορεί να έχει οποιεσδήποτε άλλες στήλες· χρειάζεται μόνο να περιέχει Α.Γ.Μ.Σ.")
        return tuple(best_values)


class BusyError(RuntimeError):
    pass


class SharedEventStore:
    def __init__(self, central_root: str | Path):
        root = Path(central_root)
        self.root = root if root.name.upper() == "TDE_DATA" else root / "TDE_DATA"
        self.events = self.root / "events"
        self.active = self.root / "active"
        self.locks = self.root / "locks"
        self.reports = self.root / "reports"
        self.shifts = self.root / "shifts"
        self.audit = self.root / "audit"
        self.backups = self.root / "backups"
        for p in (self.events, self.active, self.locks, self.reports, self.shifts, self.audit, self.backups):
            p.mkdir(parents=True, exist_ok=True)

    def _active_path(self, agms: str) -> Path:
        return self.active / f"{_safe_name(agms)}.json"

    def _lock_path(self, agms: str) -> Path:
        return self.locks / f"{_safe_name(agms)}.lock"

    @contextmanager
    def officer_lock(self, agms: str, timeout: float = 6.0):
        path = self._lock_path(agms)
        deadline = time.monotonic() + timeout
        fd = None
        while True:
            try:
                fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.write(fd, f"{socket.gethostname()}|{os.environ.get('USERNAME') or os.environ.get('USER') or ''}|{time.time()}".encode("utf-8", "ignore"))
                break
            except FileExistsError:
                try:
                    if time.time() - path.stat().st_mtime > 60:
                        path.unlink(missing_ok=True)
                        continue
                except OSError:
                    pass
                if time.monotonic() >= deadline:
                    raise BusyError("Η καταχώριση χρησιμοποιείται αυτή τη στιγμή από άλλο σταθμό. Δοκιμάστε ξανά.")
                time.sleep(0.15)
        try:
            yield
        finally:
            try:
                if fd is not None:
                    os.close(fd)
            finally:
                path.unlink(missing_ok=True)

    @staticmethod
    def _atomic_json(path: Path, data: dict):
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_name(path.name + f".{uuid.uuid4().hex}.tmp")
        temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(temp, path)

    def get_active(self, agms: str) -> dict | None:
        path = self._active_path(agms)
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return None
        except Exception:
            return None

    def _write_event(self, event: dict) -> Path:
        dt = datetime.fromisoformat(event["timestamp"])
        folder = self.events / f"{dt:%Y}" / f"{dt:%m}" / f"{dt:%Y-%m-%d}"
        filename = f"{dt:%Y%m%d_%H%M%S_%f}_{event['event_id']}.json"
        path = folder / filename
        self._atomic_json(path, event)
        return path

    def start(self, person: PersonnelRecord, position: str, direction: str, when: datetime | None = None) -> dict:
        when = when or datetime.now()
        position = _clean(position)
        direction = _clean(direction).upper()
        if not position:
            raise ValueError("Επιλέξτε θέση.")
        if direction not in {"ΕΙΣΟΔΟΣ", "ΕΞΟΔΟΣ"}:
            raise ValueError("Επιλέξτε κατεύθυνση ΕΙΣΟΔΟΣ ή ΕΞΟΔΟΣ.")
        with self.officer_lock(person.agms):
            current = self.get_active(person.agms)
            if current:
                raise ValueError(
                    f"Υπάρχει ήδη ανοικτή θέση για {person.full_name}: "
                    f"{current.get('position','')} {current.get('direction','')} από {current.get('timestamp','')}. "
                    "Πρέπει πρώτα να γίνει ΛΗΞΗ."
                )
            event = {
                "version": 2,
                "event_id": uuid.uuid4().hex,
                "kind": "START",
                "timestamp": when.isoformat(timespec="seconds"),
                "agms": person.agms,
                "rank": person.rank,
                "surname": person.surname,
                "given_name": person.given_name,
                "full_name": person.full_name,
                "position": position,
                "direction": direction,
                "computer": socket.gethostname(),
                "user": os.environ.get("USERNAME") or os.environ.get("USER") or "",
            }
            path = self._write_event(event)
            event["event_file"] = str(path)
            self._atomic_json(self._active_path(person.agms), event)
            return event

    def end(self, person: PersonnelRecord, when: datetime | None = None) -> dict:
        when = when or datetime.now()
        with self.officer_lock(person.agms):
            current = self.get_active(person.agms)
            if not current:
                raise ValueError(f"Δεν υπάρχει ανοικτή θέση για {person.full_name}.")
            event = {
                "version": 2,
                "event_id": uuid.uuid4().hex,
                "kind": "END",
                "timestamp": when.isoformat(timespec="seconds"),
                "start_event_id": current.get("event_id", ""),
                "agms": person.agms,
                "rank": current.get("rank", person.rank),
                "surname": current.get("surname", person.surname),
                "given_name": current.get("given_name", person.given_name),
                "full_name": current.get("full_name", person.full_name),
                "position": current.get("position", ""),
                "direction": current.get("direction", ""),
                "computer": socket.gethostname(),
                "user": os.environ.get("USERNAME") or os.environ.get("USER") or "",
            }
            self._write_event(event)
            self._active_path(person.agms).unlink(missing_ok=True)
            return event

    def active_all(self) -> list[dict]:
        result: list[dict] = []
        for path in sorted(self.active.glob("*.json")):
            try:
                result.append(json.loads(path.read_text(encoding="utf-8")))
            except Exception:
                pass
        return sorted(result, key=lambda x: (_clean(x.get("direction")), _clean(x.get("position")), _clean(x.get("full_name"))))

    def iter_events(self, start_dt: datetime, end_dt: datetime) -> list[dict]:
        result: list[dict] = []
        current = start_dt.date()
        last = end_dt.date()
        while current <= last:
            folder = self.events / f"{current:%Y}" / f"{current:%m}" / f"{current:%Y-%m-%d}"
            if folder.exists():
                for path in sorted(folder.glob("*.json")):
                    try:
                        e = json.loads(path.read_text(encoding="utf-8"))
                        ts = datetime.fromisoformat(e.get("timestamp", ""))
                        if start_dt <= ts < end_dt:
                            result.append(e)
                    except Exception:
                        pass
            current += timedelta(days=1)
        return sorted(result, key=lambda e: e.get("timestamp", ""))

    def save_shift(self, start_at: datetime, agms_list: list[str] | tuple[str, ...], lookback_minutes: int = 30, source_file: str = "") -> dict:
        unique = []
        seen = set()
        for value in agms_list:
            agms = _clean(value)
            if agms and agms not in seen:
                seen.add(agms); unique.append(agms)
        if not unique:
            raise ValueError("Η βάρδια δεν έχει προσωπικό.")
        lookback = max(0, min(int(lookback_minutes), 180))
        shift_id = f"SHIFT_{start_at:%Y%m%d_%H%M%S}"
        existing_path = self.shifts / f"{shift_id}.json"
        if existing_path.exists():
            try:
                existing = json.loads(existing_path.read_text(encoding="utf-8"))
                if _clean(existing.get("status")).upper() == "FINALIZED":
                    raise ValueError("Η βάρδια έχει οριστικοποιηθεί και δεν μπορεί να αντικατασταθεί.")
            except ValueError:
                raise
            except Exception:
                pass
        data = {
            "version": 1,
            "shift_id": shift_id,
            "start_at": start_at.isoformat(timespec="seconds"),
            "lookback_minutes": lookback,
            "max_window_hours": 12,
            "source_file": _clean(source_file),
            "agms": unique,
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "created_by": os.environ.get("USERNAME") or os.environ.get("USER") or "",
            "computer": socket.gethostname(),
            "status": "DRAFT",
        }
        self._atomic_json(self.shifts / f"{shift_id}.json", data)
        self.log_admin_action("SHIFT_SAVED", {"shift_id": shift_id, "people": len(unique), "lookback_minutes": lookback})
        return data

    def list_shifts(self) -> list[dict]:
        result = []
        for path in sorted(self.shifts.glob("SHIFT_*.json"), reverse=True):
            try:
                result.append(json.loads(path.read_text(encoding="utf-8")))
            except Exception:
                pass
        return result

    def roster_sessions(self, start_at: datetime, agms_list: list[str] | tuple[str, ...], lookback_minutes: int = 30, horizon_hours: int = 12) -> list[dict]:
        allowed = {_clean(x) for x in agms_list if _clean(x)}
        search_start = start_at - timedelta(minutes=max(0, int(lookback_minutes)))
        search_end = start_at + timedelta(hours=max(1, int(horizon_hours)))
        events = self.iter_events(search_start, search_end)
        starts: dict[str, dict] = {}
        sessions: list[dict] = []
        for e in events:
            if _clean(e.get("agms")) not in allowed:
                continue
            if e.get("kind") == "START":
                starts[e.get("event_id", "")] = e
            elif e.get("kind") == "END":
                sid = e.get("start_event_id", "")
                st = starts.get(sid)
                if not st:
                    continue
                sdt = datetime.fromisoformat(st["timestamp"]); edt = datetime.fromisoformat(e["timestamp"])
                sessions.append({"start": st, "end": e, "start_dt": sdt, "end_dt": edt})
        for st in self.active_all():
            if _clean(st.get("agms")) not in allowed:
                continue
            try:
                sdt = datetime.fromisoformat(st["timestamp"])
            except Exception:
                continue
            if search_start <= sdt < search_end:
                sessions.append({"start": st, "end": None, "start_dt": sdt, "end_dt": None})
        return sorted(sessions, key=lambda x: (_clean(x["start"].get("full_name")), x["start_dt"]))

    def log_admin_action(self, action: str, details: dict | None = None) -> Path:
        record = {
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "action": _clean(action),
            "details": details or {},
            "user": os.environ.get("USERNAME") or os.environ.get("USER") or "",
            "computer": socket.gethostname(),
        }
        path = self.audit / "admin_audit.jsonl"
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, ensure_ascii=False) + "\n")
        return path

    def backup_data(self) -> Path:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        target = self.backups / f"TDE_DATA_BACKUP_{stamp}.zip"
        temp = target.with_suffix(target.suffix + ".tmp")
        with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for path in self.root.rglob("*"):
                if not path.is_file():
                    continue
                try:
                    rel = path.relative_to(self.root)
                except Exception:
                    continue
                if rel.parts and rel.parts[0].lower() == "backups":
                    continue
                zf.write(path, arcname=str(rel))
        os.replace(temp, target)
        self.log_admin_action("BACKUP_CREATED", {"file": str(target)})
        return target

    def finalize_shift(self, shift: dict, report_text: str = "") -> dict:
        shift_id = _clean(shift.get("shift_id"))
        if not shift_id:
            raise ValueError("Μη έγκυρη βάρδια.")
        path = self.shifts / f"{shift_id}.json"
        try:
            current = json.loads(path.read_text(encoding="utf-8"))
        except FileNotFoundError as exc:
            raise ValueError("Δεν βρέθηκε η βάρδια για οριστικοποίηση.") from exc
        if _clean(current.get("status")).upper() == "FINALIZED":
            return current
        current["status"] = "FINALIZED"
        current["finalized_at"] = datetime.now().isoformat(timespec="seconds")
        current["finalized_by"] = os.environ.get("USERNAME") or os.environ.get("USER") or ""
        current["finalized_computer"] = socket.gethostname()
        if report_text:
            report_path = self.reports / f"FINAL_{shift_id}.txt"
            report_path.write_text(report_text, encoding="utf-8")
            current["final_report"] = str(report_path)
            current["final_report_sha256"] = hashlib.sha256(report_text.encode("utf-8")).hexdigest()
        self._atomic_json(path, current)
        self.log_admin_action("SHIFT_FINALIZED", {"shift_id": shift_id, "people": len(current.get("agms", []))})
        return current

    def shift_sessions(self, day: date, cutoff: str = DEFAULT_CUTOFF) -> tuple[datetime, datetime, list[dict]]:
        hh, mm = [int(x) for x in cutoff.split(":", 1)]
        start_dt = datetime.combine(day, dtime(hh, mm))
        end_dt = start_dt + timedelta(days=1)
        # Read a wider window so sessions that started shortly before the cutoff can still be paired if needed.
        events = self.iter_events(start_dt - timedelta(days=1), end_dt)
        starts: dict[str, dict] = {}
        sessions: list[dict] = []
        for e in events:
            if e.get("kind") == "START":
                starts[e.get("event_id", "")] = e
            elif e.get("kind") == "END":
                sid = e.get("start_event_id", "")
                s = starts.get(sid)
                if not s:
                    continue
                sdt = datetime.fromisoformat(s["timestamp"])
                edt = datetime.fromisoformat(e["timestamp"])
                if edt <= start_dt or sdt >= end_dt:
                    continue
                sessions.append({"start": s, "end": e, "start_dt": sdt, "end_dt": edt})
        # Open sessions that fall in the selected shift.
        for s in self.active_all():
            try:
                sdt = datetime.fromisoformat(s["timestamp"])
            except Exception:
                continue
            if sdt < end_dt:
                sessions.append({"start": s, "end": None, "start_dt": sdt, "end_dt": None})
        sessions.sort(key=lambda x: (x["start"].get("full_name", ""), x["start_dt"]))
        return start_dt, end_dt, sessions


def _duration_text(start_dt: datetime, end_dt: datetime | None) -> str:
    if end_dt is None:
        return "ΑΝΟΙΚΤΗ"
    minutes = max(0, int((end_dt - start_dt).total_seconds() // 60))
    h, m = divmod(minutes, 60)
    return f"{h:02d}:{m:02d}"


def build_shift_text(store: SharedEventStore, day: date, cutoff: str) -> str:
    start_dt, end_dt, sessions = store.shift_sessions(day, cutoff)
    lines = [
        "ΚΑΤΑΓΡΑΦΗ ΘΕΣΕΩΝ - ΑΝΑΦΟΡΑ ΒΑΡΔΙΑΣ",
        f"Από {start_dt:%d/%m/%Y %H:%M} έως {end_dt:%d/%m/%Y %H:%M}",
        "",
    ]
    by_person: dict[tuple[str, str], list[dict]] = {}
    for s in sessions:
        st = s["start"]
        key = (_clean(st.get("agms")), _clean(st.get("full_name")))
        by_person.setdefault(key, []).append(s)
    for (agms, name), items in sorted(by_person.items(), key=lambda x: x[0][1]):
        rank = _clean(items[0]["start"].get("rank"))
        lines.append(_clean(f"{rank} {name} (ΑΓΜΣ {agms})"))
        totals = {"ΕΙΣΟΔΟΣ": 0, "ΕΞΟΔΟΣ": 0}
        for item in items:
            st = item["start"]
            sdt = item["start_dt"]
            edt = item["end_dt"]
            end_text = edt.strftime("%H:%M:%S") if edt else "ΑΝΟΙΚΤΗ"
            lines.append(
                f"  Θ. {st.get('position','')} {st.get('direction','')} "
                f"{sdt:%H:%M:%S}–{end_text} ({_duration_text(sdt, edt)})"
            )
            if edt and st.get("direction") in totals:
                totals[st["direction"]] += max(0, int((edt - sdt).total_seconds()))
        for direction in ("ΕΙΣΟΔΟΣ", "ΕΞΟΔΟΣ"):
            sec = totals[direction]
            if sec:
                h, rem = divmod(sec, 3600)
                m = rem // 60
                lines.append(f"  Σύνολο {direction}: {h:02d}:{m:02d}")
        lines.append("")
    if not by_person:
        lines.append("Δεν υπάρχουν καταχωρίσεις για τη συγκεκριμένη βάρδια.")
    return "\n".join(lines)


def build_roster_shift_text(store: SharedEventStore, shift: dict, people_by_agms: dict[str, PersonnelRecord] | None = None) -> str:
    people_by_agms = people_by_agms or {}
    start_at = datetime.fromisoformat(shift["start_at"])
    lookback = int(shift.get("lookback_minutes", 30))
    max_window = int(shift.get("max_window_hours", 12))
    roster = [_clean(x) for x in shift.get("agms", []) if _clean(x)]
    sessions = store.roster_sessions(start_at, roster, lookback, max_window)
    by_agms: dict[str, list[dict]] = {a: [] for a in roster}
    for item in sessions:
        by_agms.setdefault(_clean(item["start"].get("agms")), []).append(item)

    lines = [
        "Τ.Δ.Ε. ΚΡΥΣΤΑΛΛΟΠΗΓΗΣ",
        "ΑΝΑΦΟΡΑ ΚΑΤΑΓΡΑΦΗΣ ΘΕΣΕΩΝ ΒΑΡΔΙΑΣ",
        f"Έναρξη βάρδιας: {start_at:%d/%m/%Y %H:%M}",
        f"Έλεγχος καταγραφών από {lookback} λεπτά πριν",
        f"Αυτόματο όριο αναζήτησης μετά την έναρξη: {max_window} ώρες",
        "",
    ]
    position_seconds: dict[str, int] = {}
    open_count = 0
    people_with_activity = 0

    for agms in roster:
        items = sorted(by_agms.get(agms, []), key=lambda x: x["start_dt"])
        person = people_by_agms.get(agms)
        if person:
            header = _clean(f"{person.rank} {person.surname} {person.given_name}")
        elif items:
            st = items[0]["start"]; header = _clean(f"{st.get('rank','')} {st.get('full_name','')}") or f"ΑΓΜΣ {agms}"
        else:
            header = f"ΑΓΜΣ {agms}"
        lines.append(header)
        lines.append(f"Α.Γ.Μ.Σ. {agms}")
        if not items:
            lines.append("  Χωρίς καταχώριση θέσης")
            lines.append("")
            continue
        people_with_activity += 1
        total_sec = 0
        for item in items:
            st = item["start"]; sdt = item["start_dt"]; edt = item["end_dt"]
            end_text = edt.strftime("%H:%M") if edt else "ΑΝΟΙΚΤΗ"
            dur = _duration_text(sdt, edt)
            lines.append(f"  ΘΕΣΗ {st.get('position',''):<3}  {st.get('direction',''):<7}  {sdt:%H:%M} - {end_text:<7}  {dur}")
            if edt:
                sec = max(0, int((edt-sdt).total_seconds()))
                total_sec += sec
                pos = _clean(st.get("position")); position_seconds[pos] = position_seconds.get(pos, 0) + sec
            else:
                open_count += 1
        h, rem = divmod(total_sec, 3600); m = rem // 60
        lines.append(f"  ΣΥΝΟΛΟ: {h}ω {m:02d}λ")
        lines.append("")

    lines.append("ΣΥΝΟΨΗ")
    lines.append(f"Προσωπικό βάρδιας: {len(roster)}")
    lines.append(f"Προσωπικό με καταγραφές: {people_with_activity}")
    for pos in sorted(position_seconds, key=lambda x: (not x.isdigit(), int(x) if x.isdigit() else x)):
        sec = position_seconds[pos]; h, rem = divmod(sec, 3600); m = rem // 60
        lines.append(f"Θέση {pos}: {h}ω {m:02d}λ")
    lines.append(f"Ανοικτές καταχωρίσεις χωρίς ΛΗΞΗ: {open_count}")
    return "\n".join(lines)


def build_roster_shift_html(store: SharedEventStore, shift: dict, people_by_agms: dict[str, PersonnelRecord] | None = None) -> str:
    text = build_roster_shift_text(store, shift, people_by_agms)
    return f"""<!doctype html><html><head><meta charset='utf-8'><title>Αναφορά Βάρδιας</title>
<style>body{{font-family:Segoe UI,Arial,sans-serif;margin:28px;color:#183247}}pre{{font-family:Consolas,'Courier New',monospace;font-size:11pt;white-space:pre-wrap;line-height:1.45}}@media print{{body{{margin:12mm}}}}</style>
</head><body><pre>{_escape_html(text)}</pre></body></html>"""


def _escape_html(text: str) -> str:
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def build_shift_html(store: SharedEventStore, day: date, cutoff: str) -> str:
    text = build_shift_text(store, day, cutoff)
    return f"""<!doctype html><html><head><meta charset='utf-8'><title>Αναφορά Βάρδιας</title>
<style>body{{font-family:Segoe UI,Arial,sans-serif;margin:28px;color:#183247}}pre{{font-family:Consolas,'Courier New',monospace;font-size:11pt;white-space:pre-wrap}}@media print{{body{{margin:12mm}}}}</style>
</head><body><pre>{_escape_html(text)}</pre></body></html>"""


def run(args=None) -> int:
    from PySide6.QtCore import Qt, QDate, QDateTime, QTimer, QRectF
    from PySide6.QtGui import QColor, QFont, QPainter, QPen
    from PySide6.QtWidgets import (
        QApplication, QComboBox, QDateEdit, QFileDialog, QFormLayout, QFrame, QHBoxLayout,
        QLabel, QLineEdit, QMainWindow, QMessageBox, QPushButton, QTextBrowser, QVBoxLayout, QWidget,
        QInputDialog, QDialog, QDateTimeEdit, QSpinBox, QListWidget, QGraphicsDropShadowEffect
    )

    class BoothMapWidget(QWidget):
        BOOTH_POS = {
            "7": (0.46, 0.10), "6": (0.52, 0.10),
            "5": (0.52, 0.24), "4": (0.52, 0.32),
            "3": (0.40, 0.40), "2": (0.46, 0.40), "1": (0.52, 0.40),
            "10": (0.40, 0.64), "9": (0.46, 0.64), "8": (0.52, 0.64),
            "11": (0.52, 0.72), "12": (0.52, 0.80),
            "14": (0.46, 0.90), "13": (0.52, 0.90),
        }

        def __init__(self, parent=None):
            super().__init__(parent)
            self.active: dict[str, list[dict]] = {}
            self.setMinimumSize(760, 560)

        def set_active(self, items: list[dict]):
            grouped: dict[str, list[dict]] = {}
            for item in items:
                grouped.setdefault(_clean(item.get("position")), []).append(item)
            self.active = grouped
            self.update()

        def paintEvent(self, event):
            painter = QPainter(self)
            painter.setRenderHint(QPainter.Antialiasing)
            w, h = self.width(), self.height()
            painter.fillRect(self.rect(), QColor("#06101c"))

            # ground / lanes
            painter.setPen(QPen(QColor("#17364e"), 1))
            step = 42
            for x in range(0, w, step): painter.drawLine(x, 0, x, h)
            for y in range(0, h, step): painter.drawLine(0, y, w, y)
            painter.setPen(QPen(QColor("#69849a"), 2, Qt.DashLine))
            for frac in (0.18, 0.34, 0.68, 0.84):
                y = int(h * frac); painter.drawLine(30, y, w - 30, y)

            # buildings
            painter.setPen(QPen(QColor("#38bdf8"), 2))
            painter.setBrush(QColor("#162638"))
            buildings = [(0.10,0.49,0.22,0.10,"ΤΕΛΩΝΕΙΟ"),(0.34,0.49,0.22,0.10,"ΑΣΤΥΝΟΜΙΑ"),(0.58,0.49,0.15,0.10,"ΑΞ/ΚΟΣ ΥΠΗΡΕΣΙΑΣ")]
            painter.setFont(QFont("Segoe UI", 10, QFont.Bold))
            for x,y,bw,bh,label in buildings:
                r=QRectF(w*x,h*y,w*bw,h*bh); painter.drawRoundedRect(r,8,8); painter.drawText(r,Qt.AlignCenter,label)

            # labels
            painter.setFont(QFont("Segoe UI", 12, QFont.Bold))
            painter.setPen(QColor("#4ade80")); painter.drawText(QRectF(w*0.76,h*0.18,w*0.20,h*0.08),Qt.AlignCenter,"ΕΙΣΟΔΟΣ ↑")
            painter.setPen(QColor("#f87171")); painter.drawText(QRectF(w*0.76,h*0.70,w*0.20,h*0.08),Qt.AlignCenter,"ΕΞΟΔΟΣ ↓")

            # booths
            bw = max(54, int(w*0.075)); bh = max(46, int(h*0.075))
            for pos,(xf,yf) in self.BOOTH_POS.items():
                x=int(w*xf); y=int(h*yf)
                r=QRectF(x,y,bw,bh)
                people=self.active.get(pos,[])
                occupied=bool(people)
                # subtle pseudo-3D depth: shadow + lower/right faces, then main face
                shadow_r = QRectF(r.x()+7, r.y()+8, r.width(), r.height())
                painter.setPen(Qt.NoPen)
                painter.setBrush(QColor(0, 0, 0, 95))
                painter.drawRoundedRect(shadow_r, 9, 9)
                painter.setBrush(QColor("#0f5f3f" if occupied else "#064865"))
                painter.drawRoundedRect(QRectF(r.x()+4, r.y()+5, r.width(), r.height()), 9, 9)
                painter.setPen(QPen(QColor("#a7f3d0" if occupied else "#bae6fd"),2))
                painter.setBrush(QColor("#1f9d68" if occupied else "#0878a8"))
                painter.drawRoundedRect(r,9,9)
                # highlight on upper edge for a raised/card-like effect
                painter.setPen(QPen(QColor(255,255,255,70),1))
                painter.drawLine(int(r.x()+7), int(r.y()+4), int(r.right()-7), int(r.y()+4))
                painter.setPen(QColor("#ffffff"))
                painter.setFont(QFont("Segoe UI", 11, QFont.Bold))
                painter.drawText(QRectF(r.x(),r.y()+2,r.width(),18),Qt.AlignCenter,f"ΘΕΣΗ {pos}")
                if people:
                    names=[]
                    for item in people[:2]:
                        surname=_clean(item.get("surname")) or _clean(item.get("full_name"))
                        ts=_clean(item.get("timestamp")).replace("T"," ")
                        hhmm=ts[11:16] if len(ts)>=16 else ""
                        direction=_clean(item.get("direction"))
                        names.append(f"{surname}\n{direction} {hhmm}".strip())
                    if len(people)>2: names.append(f"+{len(people)-2} ακόμη")
                    painter.setFont(QFont("Segoe UI", 8, QFont.Bold))
                    painter.drawText(QRectF(r.x()+3,r.y()+19,r.width()-6,r.height()-21),Qt.AlignCenter|Qt.TextWordWrap,"\n".join(names))

    class LiveMapDialog(QDialog):
        def __init__(self, store: SharedEventStore, parent=None):
            super().__init__(parent)
            self.store = store
            self.setWindowTitle("ΑΞΙΩΜΑΤΙΚΟΣ ΥΠΗΡΕΣΙΑΣ - Ζωντανή εικόνα θέσεων")
            self.resize(1100, 760)
            self.setStyleSheet("""
                QDialog{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #eef5f9,stop:1 #dfeaf1);}
                QLabel{color:#193b50;}
            """)
            lay=QVBoxLayout(self); lay.setContentsMargins(22,22,22,22); lay.setSpacing(14)
            top=QHBoxLayout()
            title=QLabel("ΖΩΝΤΑΝΗ ΕΙΚΟΝΑ ΘΕΣΕΩΝ"); title.setStyleSheet("font-size:22px;font-weight:900;color:#123f5a;letter-spacing:1px")
            self.updated=QLabel("")
            top.addWidget(title); top.addStretch(); top.addWidget(self.updated)
            lay.addLayout(top)
            self.map=BoothMapWidget(); lay.addWidget(self.map,1)
            self.other=QLabel(""); self.other.setWordWrap(True); self.other.setStyleSheet("background:#ffffff;border:1px solid #cfdae2;padding:10px 12px;border-radius:12px;color:#36596f;font-weight:600")
            lay.addWidget(self.other)
            self.timer=QTimer(self); self.timer.timeout.connect(self.refresh); self.timer.start(2000)
            self.refresh()

        def refresh(self):
            items=self.store.active_all()
            self.map.set_active(items)
            other=[]
            for x in items:
                pos=_clean(x.get("position"))
                if pos not in BoothMapWidget.BOOTH_POS:
                    other.append(f"{x.get('rank','')} {x.get('full_name','')} — {pos} — {x.get('direction','')} — από {_clean(x.get('timestamp')).replace('T',' ')}")
            self.other.setText("Άλλες ενεργές θέσεις: " + (" | ".join(other) if other else "καμία"))
            self.updated.setText("Ενημέρωση: " + datetime.now().strftime("%H:%M:%S"))

    class MainWindow(QMainWindow):
        def __init__(self):
            super().__init__()
            self.config = AppConfig.load()
            self.people: tuple[PersonnelRecord, ...] = ()
            self._people_by_agms: dict[str, PersonnelRecord] = {}
            self.store: SharedEventStore | None = None
            self.setWindowTitle("Τ.Δ.Ε. Κρυσταλλοπηγής - Καταγραφή Θέσεων")
            self.resize(900, 620)
            self.setMinimumSize(780, 560)
            self._build()
            self._apply_config()

        def _build(self):
            root = QWidget(); self.setCentralWidget(root)
            root.setObjectName("rootPanel")
            root.setStyleSheet("""
                QWidget#rootPanel {
                    background: qlineargradient(x1:0,y1:0,x2:1,y2:1,
                        stop:0 #eef5f9, stop:0.55 #f8fbfd, stop:1 #e8f0f5);
                }
                QLabel { color:#1b3447; }
                QLineEdit, QComboBox {
                    background:#ffffff;
                    border:1px solid #c9d8e3;
                    border-radius:10px;
                    padding:7px 10px;
                    color:#17374e;
                    selection-background-color:#2f6f98;
                }
                QLineEdit:focus, QComboBox:focus {
                    border:2px solid #3a82ad;
                    background:#ffffff;
                }
                QComboBox::drop-down { border:0; width:34px; }
                QPushButton {
                    border-radius:10px;
                    border:1px solid #c3d2dc;
                    background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #ffffff,stop:1 #e8eef2);
                    color:#24475d;
                    font-weight:700;
                    padding:8px 16px;
                }
                QPushButton:hover { border-color:#7fa5bd; background:#f8fbfd; }
                QPushButton:pressed { padding-top:10px; padding-bottom:6px; background:#dfe8ee; }
            """)
            layout = QVBoxLayout(root); layout.setContentsMargins(34,28,34,28); layout.setSpacing(15)

            title = QLabel("Τ.Δ.Ε. ΚΡΥΣΤΑΛΛΟΠΗΓΗΣ")
            title.setAlignment(Qt.AlignCenter)
            title.setStyleSheet("font-size:27px;font-weight:900;color:#123f5a;letter-spacing:1px")
            layout.addWidget(title)
            subtitle = QLabel("ΚΑΤΑΓΡΑΦΗ ΘΕΣΕΩΝ")
            subtitle.setAlignment(Qt.AlignCenter)
            subtitle.setStyleSheet("font-size:18px;font-weight:800;color:#4a6b80;letter-spacing:2px")
            layout.addWidget(subtitle)

            card = QFrame()
            card.setObjectName("mainCard")
            card.setStyleSheet("QFrame#mainCard{background:#ffffff;border:1px solid #d4e0e8;border-radius:18px;padding:16px}")
            card_shadow = QGraphicsDropShadowEffect(card)
            card_shadow.setBlurRadius(28); card_shadow.setOffset(0,7); card_shadow.setColor(QColor(20,55,75,55))
            card.setGraphicsEffect(card_shadow)
            form = QFormLayout(card); form.setSpacing(15)

            self.agms_input = QLineEdit()
            self.agms_input.setPlaceholderText("Πληκτρολογήστε Α.Γ.Μ.Σ.")
            self.agms_input.setMinimumHeight(42)
            self.agms_input.setStyleSheet("font-size:18px;font-weight:800;padding:7px 10px")
            self.agms_input.textChanged.connect(self._agms_changed)

            self.person_name = QLabel("—")
            self.person_name.setStyleSheet("font-size:17px;font-weight:700;color:#17374e")
            self.person_name.setWordWrap(True)

            self.direction = QComboBox()
            self.direction.setEditable(False)
            self.direction.addItems(["ΕΙΣΟΔΟΣ", "ΕΞΟΔΟΣ"])
            self.direction.setMinimumHeight(42)
            self.direction.setStyleSheet("font-size:17px;font-weight:700;padding:6px 9px")

            self.position = QComboBox()
            self.position.setEditable(False)
            self.position.setMinimumHeight(42)
            self.position.setStyleSheet("font-size:17px;font-weight:700;padding:6px 9px")
            self.position.currentTextChanged.connect(self._position_changed)

            form.addRow("Α.Γ.Μ.Σ.", self.agms_input)
            form.addRow("Αστυνομικός", self.person_name)
            form.addRow("ΚΑΤΕΥΘΥΝΣΗ", self.direction)
            form.addRow("ΘΕΣΗ", self.position)
            layout.addWidget(card)

            self.active_status = QLabel("Πληκτρολογήστε Α.Γ.Μ.Σ.")
            self.active_status.setWordWrap(True)
            self.active_status.setStyleSheet("color:#617b8c;font-size:13px;padding:4px 2px")
            layout.addWidget(self.active_status)

            actions = QHBoxLayout(); actions.setSpacing(16)
            self.start_btn = QPushButton("ΕΝΑΡΞΗ")
            self.start_btn.setMinimumHeight(64); self.start_btn.clicked.connect(self._start)
            self.end_btn = QPushButton("ΛΗΞΗ")
            self.end_btn.setMinimumHeight(64); self.end_btn.clicked.connect(self._end)
            self.start_btn.setStyleSheet("""QPushButton{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #35a978,stop:1 #1e7958);color:white;font-size:19px;font-weight:900;border:1px solid #176247;border-radius:12px;}QPushButton:hover{background:#2a966c;}QPushButton:pressed{background:#176247;padding-top:4px;}""")
            self.end_btn.setStyleSheet("""QPushButton{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #df7257,stop:1 #b84d38);color:white;font-size:19px;font-weight:900;border:1px solid #9f402f;border-radius:12px;}QPushButton:hover{background:#cd624a;}QPushButton:pressed{background:#9f402f;padding-top:4px;}""")
            for _b, _c in ((self.start_btn, QColor(19,92,67,85)), (self.end_btn, QColor(123,53,37,75))):
                _sh = QGraphicsDropShadowEffect(_b); _sh.setBlurRadius(20); _sh.setOffset(0,5); _sh.setColor(_c); _b.setGraphicsEffect(_sh)
            actions.addWidget(self.start_btn); actions.addWidget(self.end_btn)
            layout.addLayout(actions)

            secondary = QHBoxLayout(); secondary.setSpacing(12)
            b_report = QPushButton("ΑΝΑΦΟΡΕΣ"); b_report.setMinimumHeight(42); b_report.clicked.connect(self._report)
            b_admin = QPushButton("ΑΞΙΩΜΑΤΙΚΟΣ ΥΠΗΡΕΣΙΑΣ"); b_admin.setMinimumHeight(42); b_admin.clicked.connect(self._admin)
            secondary.addStretch(); secondary.addWidget(b_report); secondary.addWidget(b_admin)
            layout.addLayout(secondary)

            self.info = QLabel("")
            self.info.setWordWrap(True)
            self.info.setAlignment(Qt.AlignCenter)
            self.info.setStyleSheet("background:rgba(255,255,255,180);border:1px solid #d7e2e9;border-radius:9px;color:#587184;font-size:11px;font-weight:650;padding:6px 10px")
            layout.addWidget(self.info)
            layout.addStretch()

            credits = QLabel("ΑΝΘ/ΜΟΣ ΔΑΝΙΗΛΙΔΗΣ ΗΡΑΚΛΗΣ   •   ΑΝΘ/ΜΟΣ ΚΛΙΑΝΗΣ ΧΡΗΣΤΟΣ")
            credits.setAlignment(Qt.AlignCenter)
            credits.setStyleSheet("color:#8094a2;font-size:9px;font-weight:600;letter-spacing:0.5px")
            layout.addWidget(credits)

        def _apply_config(self):
            self.position.clear(); self.position.addItems(self.config.positions or [])
            self._position_changed(self.position.currentText())
            if self.config.central_root:
                try:
                    self.store = SharedEventStore(self.config.central_root)
                except Exception as exc:
                    self.store = None
                    self.info.setText(f"Πρόβλημα κεντρικού φακέλου: {exc}")
            if self.config.personnel_file:
                try:
                    self._load_people(self.config.personnel_file)
                except Exception as exc:
                    self.info.setText(f"Πρόβλημα προσωπικού: {exc}")
            self._refresh_info(); self._agms_changed()

        def _refresh_info(self):
            if self.store and self.people:
                self.info.setText("Σύστημα έτοιμο")
            elif not self.store:
                self.info.setText("Απαιτείται ρύθμιση κεντρικού φακέλου από ΑΞΙΩΜΑΤΙΚΟ ΥΠΗΡΕΣΙΑΣ")
            else:
                self.info.setText("Απαιτείται αρχείο προσωπικού από ΑΞΙΩΜΑΤΙΚΟ ΥΠΗΡΕΣΙΑΣ")

        def _save_config(self):
            self.config.positions = [self.position.itemText(i) for i in range(self.position.count()) if _clean(self.position.itemText(i))]
            self.config.save()
            self._refresh_info()

        def _choose_root(self):
            path = QFileDialog.getExistingDirectory(self, "Επιλογή κεντρικού φακέλου")
            if not path: return
            try:
                self.store = SharedEventStore(path)
                self.config.central_root = path
                self._save_config(); self._agms_changed()
                self.store.log_admin_action("CENTRAL_ROOT_SET", {"path": path})
            except Exception as exc:
                QMessageBox.critical(self, "Σφάλμα", str(exc))

        def _choose_people(self):
            path, _ = QFileDialog.getOpenFileName(self, "Επιλογή αρχείου προσωπικού", str(Path.home()), "Excel (*.xlsx *.xlsm)")
            if not path: return
            try:
                self._load_people(path)
                self.config.personnel_file = path
                self._save_config()
                missing_names = sum(1 for p in self.people if not _clean(f"{p.surname} {p.given_name}"))
                if self.store:
                    self.store.log_admin_action("PERSONNEL_FILE_SET", {"path": path, "count": len(self.people), "without_name": missing_names})
                msg = f"Φορτώθηκαν {len(self.people)} άτομα."
                if missing_names:
                    msg += f"\n{missing_names} Α.Γ.Μ.Σ. δεν έχουν ονοματεπώνυμο στο αρχείο, αλλά παραμένουν διαθέσιμοι για χρήση."
                QMessageBox.information(self, "Προσωπικό", msg)
            except Exception as exc:
                QMessageBox.critical(self, "Σφάλμα", str(exc))

        def _load_people(self, path: str):
            self.people = PersonnelRepository.load(path)
            self._people_by_agms = {_clean(p.agms): p for p in self.people}
            self._agms_changed()

        def _selected(self) -> PersonnelRecord | None:
            agms = _clean(self.agms_input.text()) if hasattr(self, "agms_input") else ""
            return getattr(self, "_people_by_agms", {}).get(agms)

        def _agms_changed(self, *_):
            p = self._selected()
            if not p:
                self.person_name.setText("—")
                if _clean(self.agms_input.text()):
                    self.active_status.setText("Ο Α.Γ.Μ.Σ. δεν βρέθηκε στο προσωπικό")
                    self.active_status.setStyleSheet("color:#a23f2c;font-weight:700;padding:4px 2px")
                else:
                    self.active_status.setText("Πληκτρολογήστε Α.Γ.Μ.Σ.")
                    self.active_status.setStyleSheet("color:#617b8c;padding:4px 2px")
                self.start_btn.setEnabled(False); self.end_btn.setEnabled(False)
                return

            display_name = _clean(f"{p.rank} {p.surname} {p.given_name}")
            self.person_name.setText(display_name or f"Α.Γ.Μ.Σ. {p.agms} — χωρίς στοιχεία ονόματος")
            active = self.store.get_active(p.agms) if self.store else None
            if active:
                ts = _clean(active.get("timestamp", "")).replace("T", " ")
                self.active_status.setText(
                    f"ΕΝΕΡΓΗ: ΘΕΣΗ {active.get('position','')} — {active.get('direction','')} — από {ts}"
                )
                self.active_status.setStyleSheet("color:#a23f2c;font-size:15px;font-weight:800;padding:4px 2px")
                self.start_btn.setEnabled(False); self.end_btn.setEnabled(True)
            else:
                self.active_status.setText("Δεν υπάρχει ανοικτή καταχώριση")
                self.active_status.setStyleSheet("color:#267052;font-size:14px;font-weight:700;padding:4px 2px")
                self.start_btn.setEnabled(bool(self.store)); self.end_btn.setEnabled(False)

        @staticmethod
        def _suggested_direction(position: str) -> str:
            pos = _clean(position)
            if pos.isdigit():
                n = int(pos)
                if 1 <= n <= 7:
                    return "ΕΙΣΟΔΟΣ"
                if 8 <= n <= 14:
                    return "ΕΞΟΔΟΣ"
            return "ΕΙΣΟΔΟΣ"

        def _position_changed(self, position: str):
            # Πρόταση μόνο όταν αλλάζει η θέση. Ο χειριστής μπορεί αμέσως μετά
            # να αλλάξει ελεύθερα ΕΙΣΟΔΟΣ/ΕΞΟΔΟΣ πριν πατήσει ΕΝΑΡΞΗ.
            if hasattr(self, "direction"):
                suggested = self._suggested_direction(position)
                idx = self.direction.findText(suggested)
                if idx >= 0:
                    self.direction.setCurrentIndex(idx)

        def _start(self):
            p = self._selected()
            if not p or not self.store:
                QMessageBox.warning(self, "Έλεγχος", "Ορίστε κεντρικό φάκελο και προσωπικό."); return
            pos = _clean(self.position.currentText())
            direction = _clean(self.direction.currentText()).upper()
            try:
                if pos not in {str(i) for i in range(1, 15)}:
                    raise ValueError("Επιλέξτε θέση 1 έως 14.")
                if direction not in {"ΕΙΣΟΔΟΣ", "ΕΞΟΔΟΣ"}:
                    raise ValueError("Επιλέξτε κατεύθυνση ΕΙΣΟΔΟΣ ή ΕΞΟΔΟΣ.")
                e = self.store.start(p, pos, direction)
                QMessageBox.information(
                    self, "Καταχώριση",
                    f"ΕΝΑΡΞΗ: ΘΕΣΗ {pos} — {direction}\nΏρα: {e['timestamp'].replace('T',' ')}"
                )
                self._agms_changed()
            except Exception as exc:
                QMessageBox.critical(self, "Δεν καταχωρίστηκε", str(exc))

        def _end(self):
            p = self._selected()
            if not p or not self.store:
                QMessageBox.warning(self, "Έλεγχος", "Ορίστε κεντρικό φάκελο και προσωπικό."); return
            try:
                e = self.store.end(p)
                QMessageBox.information(self, "Καταχώριση", f"ΛΗΞΗ καταχωρίστηκε στις {e['timestamp'].replace('T',' ')}")
                self._agms_changed()
            except Exception as exc:
                QMessageBox.critical(self, "Δεν καταχωρίστηκε", str(exc))

        def _backup(self):
            if not self.store:
                QMessageBox.warning(self, "Backup", "Ορίστε πρώτα κεντρικό φάκελο δεδομένων.")
                return
            try:
                path = self.store.backup_data()
                QMessageBox.information(self, "Backup", f"Το αντίγραφο ασφαλείας δημιουργήθηκε:\n{path}")
            except Exception as exc:
                QMessageBox.critical(self, "Backup", str(exc))

        def _audit_view(self):
            if not self.store:
                QMessageBox.warning(self, "Audit log", "Ορίστε πρώτα κεντρικό φάκελο δεδομένων.")
                return
            path = self.store.audit / "admin_audit.jsonl"
            if not path.exists():
                QMessageBox.information(self, "Ιστορικό ενεργειών", "Δεν υπάρχουν ακόμη καταγραφές ενεργειών.")
                return
            dlg = QDialog(self); dlg.setWindowTitle("ΑΞΙΩΜΑΤΙΚΟΣ ΥΠΗΡΕΣΙΑΣ - Ιστορικό ενεργειών"); dlg.resize(900, 600)
            lay = QVBoxLayout(dlg); browser = QTextBrowser(); browser.setStyleSheet("font-family:Consolas,monospace")
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()[-300:]
            pretty=[]
            for line in lines:
                try:
                    r=json.loads(line); pretty.append(f"{r.get('timestamp','')} | {r.get('user','')}@{r.get('computer','')} | {r.get('action','')} | {json.dumps(r.get('details',{}),ensure_ascii=False)}")
                except Exception:
                    pretty.append(line)
            browser.setPlainText("\n".join(pretty)); lay.addWidget(browser); dlg.exec()

        def _admin(self):
            # Άμεση πρόσβαση: ο Αξιωματικός Υπηρεσίας δεν χρειάζεται PIN.
            if self.store:
                try:
                    self.store.log_admin_action("OFFICER_DUTY_PANEL_OPENED")
                except Exception:
                    pass
            dlg = QDialog(self)
            dlg.setWindowTitle("ΑΞΙΩΜΑΤΙΚΟΣ ΥΠΗΡΕΣΙΑΣ")
            dlg.resize(570, 520)
            dlg.setStyleSheet("""
                QDialog{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #edf4f8,stop:1 #dde9f0);}
                QLabel{color:#23465c;}
                QPushButton{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #ffffff,stop:1 #e4edf2);border:1px solid #bcced9;border-radius:11px;color:#24485f;font-weight:750;padding:9px 14px;text-align:left;}
                QPushButton:hover{border:1px solid #6f9bb5;background:#f9fcfd;}
                QPushButton:pressed{background:#d7e4ec;padding-top:11px;padding-bottom:7px;}
            """)
            lay = QVBoxLayout(dlg); lay.setContentsMargins(24,22,24,22); lay.setSpacing(10)
            header = QLabel("ΑΞΙΩΜΑΤΙΚΟΣ ΥΠΗΡΕΣΙΑΣ"); header.setStyleSheet("font-size:20px;font-weight:900;color:#123f5a;letter-spacing:1px")
            lay.addWidget(header)
            note = QLabel("Επιλέξτε την εργασία που θέλετε. Οι επιλογές αυτές δεν εμφανίζονται στους χειριστές.")
            note.setWordWrap(True); note.setStyleSheet("background:#ffffff;border:1px solid #d2dfe7;border-radius:10px;padding:10px;color:#536f80")
            lay.addWidget(note)
            b_root = QPushButton("Ορισμός κεντρικού φακέλου δεδομένων"); b_root.clicked.connect(self._choose_root)
            b_people = QPushButton("Ορισμός αρχείου προσωπικού (Excel)"); b_people.clicked.connect(self._choose_people)
            b_shift = QPushButton("Διαχείριση βάρδιας"); b_shift.clicked.connect(self._shift_admin)
            b_map = QPushButton("Ζωντανή εικόνα θέσεων"); b_map.clicked.connect(self._live_map)
            b_snapshot = QPushButton("Λίστα ανοικτών θέσεων"); b_snapshot.clicked.connect(self._snapshot)
            b_backup = QPushButton("Δημιουργία αντιγράφου ασφαλείας"); b_backup.clicked.connect(self._backup)
            b_audit = QPushButton("Ιστορικό ενεργειών"); b_audit.clicked.connect(self._audit_view)
            for b in (b_shift, b_map, b_snapshot, b_backup, b_audit, b_root, b_people):
                b.setMinimumHeight(44)
                _sh = QGraphicsDropShadowEffect(b); _sh.setBlurRadius(14); _sh.setOffset(0,3); _sh.setColor(QColor(30,60,80,40)); b.setGraphicsEffect(_sh)
                lay.addWidget(b)
            lay.addStretch()
            dlg.exec()

        def _live_map(self):
            if not self.store:
                QMessageBox.warning(self, "Έλεγχος", "Ορίστε πρώτα κεντρικό φάκελο δεδομένων.")
                return
            LiveMapDialog(self.store, self).exec()

        def _shift_admin(self):
            if not self.store:
                QMessageBox.warning(self, "Έλεγχος", "Ορίστε πρώτα κεντρικό φάκελο δεδομένων.")
                return
            dlg = QDialog(self); dlg.setWindowTitle("ΑΞΙΩΜΑΤΙΚΟΣ ΥΠΗΡΕΣΙΑΣ - Νέα βάρδια"); dlg.resize(800, 680)
            dlg.setStyleSheet("""
                QDialog{background:#eef4f7;}
                QLabel{color:#24485e;}
                QLineEdit,QDateTimeEdit,QSpinBox,QListWidget,QTextBrowser{background:#ffffff;border:1px solid #c8d7e0;border-radius:9px;padding:6px;}
                QPushButton{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #ffffff,stop:1 #e4edf2);border:1px solid #bfcfd9;border-radius:9px;padding:8px 12px;font-weight:700;color:#24485e;}
                QPushButton:hover{border-color:#729bb3;background:#f9fcfd;}
            """)
            lay = QVBoxLayout(dlg); lay.setContentsMargins(22,20,22,20); lay.setSpacing(10)
            help_text = QLabel("ΒΗΜΑ 1: Επιλέξτε το Excel προσωπικού.   ΒΗΜΑ 2: Ελέγξτε ημερομηνία/ώρα έναρξης.   ΒΗΜΑ 3: Ελέγξτε τη λίστα και την προεπισκόπηση.   ΒΗΜΑ 4: Οριστικοποιήστε μόνο όταν είναι σωστά.")
            help_text.setWordWrap(True); help_text.setStyleSheet("font-weight:700;color:#315b73")
            lay.addWidget(help_text)

            roster_path = QLineEdit(); roster_path.setReadOnly(True); roster_path.setPlaceholderText("Δεν έχει επιλεγεί Excel βάρδιας")
            choose = QPushButton("Επιλογή Excel προσωπικού βάρδιας")
            count_label = QLabel("Προσωπικό: 0 άτομα")
            roster_list = QListWidget(); roster_list.setMinimumHeight(150)
            add_row = QHBoxLayout(); add_agms = QLineEdit(); add_agms.setPlaceholderText("Α.Γ.Μ.Σ. για προσθήκη")
            add_btn = QPushButton("Προσθήκη"); remove_btn = QPushButton("Αφαίρεση επιλεγμένου")
            add_row.addWidget(add_agms); add_row.addWidget(add_btn); add_row.addWidget(remove_btn)
            dt_edit = QDateTimeEdit(QDateTime.currentDateTime()); dt_edit.setCalendarPopup(True); dt_edit.setDisplayFormat("dd/MM/yyyy HH:mm")
            lookback = QSpinBox(); lookback.setRange(0, 180); lookback.setValue(30); lookback.setSuffix(" λεπτά")
            preview = QTextBrowser(); preview.setStyleSheet("font-family:Consolas,monospace;background:#ffffff;border:1px solid #c8d7e0;border-radius:10px;padding:8px")
            save = QPushButton("ΑΠΟΘΗΚΕΥΣΗ ΠΡΟΣΩΡΙΝΑ"); save.setMinimumHeight(46)
            finalize = QPushButton("ΟΡΙΣΤΙΚΟΠΟΙΗΣΗ ΒΑΡΔΙΑΣ"); finalize.setMinimumHeight(50)
            finalize.setStyleSheet("QPushButton{background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #39a576,stop:1 #1d7555);color:white;font-weight:900;border:1px solid #176247;border-radius:11px;}QPushButton:hover{background:#2d9168;}")
            shift_status = QLabel("Κατάσταση: ΠΡΟΣΩΡΙΝΗ")
            shift_status.setStyleSheet("font-weight:700;color:#8a5a16")
            roster_agms: list[str] = []

            form = QFormLayout(); form.addRow("Excel βάρδιας", roster_path); form.addRow("Έναρξη βάρδιας", dt_edit); form.addRow("Έλεγχος πριν την έναρξη", lookback)
            lay.addWidget(choose); lay.addWidget(count_label); lay.addWidget(roster_list); lay.addLayout(add_row); lay.addLayout(form); lay.addWidget(QLabel("Προεπισκόπηση καταγραφών")); lay.addWidget(preview); lay.addWidget(shift_status); lay.addWidget(save); lay.addWidget(finalize)

            def current_start() -> datetime:
                q = dt_edit.dateTime(); d = q.date(); t = q.time()
                return datetime(d.year(), d.month(), d.day(), t.hour(), t.minute(), t.second())

            def refresh_roster_list():
                roster_list.clear()
                for agms in roster_agms:
                    person = self._people_by_agms.get(agms)
                    label = f"{agms} - {_clean(f'{person.rank} {person.full_name}') if person else 'δεν βρέθηκε στο κύριο προσωπικό'}"
                    roster_list.addItem(label)
                count_label.setText(f"Προσωπικό: {len(roster_agms)} άτομα")

            def refresh_preview():
                if not roster_agms:
                    preview.setPlainText("Επιλέξτε πρώτα το Excel βάρδιας."); return
                sessions = self.store.roster_sessions(current_start(), roster_agms, lookback.value(), 12)
                by_agms: dict[str, list[dict]] = {}
                for item in sessions:
                    by_agms.setdefault(_clean(item["start"].get("agms")), []).append(item)
                lines = [f"Προσωπικό βάρδιας: {len(roster_agms)}", f"Έναρξη: {current_start():%d/%m/%Y %H:%M}", f"Αναζήτηση από {lookback.value()} λεπτά πριν", "Αυτόματο όριο μετά την έναρξη: 12 ώρες", ""]
                for agms in roster_agms:
                    person = self._people_by_agms.get(agms)
                    name = _clean(f"{person.rank} {person.full_name}") if person else f"ΑΓΜΣ {agms}"
                    items = by_agms.get(agms, [])
                    if not items:
                        lines.append(f"{name}: χωρίς καταχώριση")
                        continue
                    first = min(x["start_dt"] for x in items)
                    lines.append(f"{name}: πρώτη έναρξη {first:%H:%M}")
                    for item in items:
                        st = item["start"]; edt = item["end_dt"]
                        end_text = edt.strftime("%H:%M") if edt else "ΑΝΟΙΚΤΗ"
                        lines.append(f"  Θ. {st.get('position','')} — {st.get('direction','')} — {item['start_dt']:%H:%M} - {end_text}")
                preview.setPlainText("\n".join(lines))

            def choose_roster():
                path, _ = QFileDialog.getOpenFileName(dlg, "Επιλογή Excel βάρδιας", str(Path.home()), "Excel (*.xlsx *.xlsm)")
                if not path: return
                try:
                    values = list(ShiftRosterRepository.load_agms(path, set(self._people_by_agms)))
                    roster_agms.clear(); roster_agms.extend(values)
                    roster_path.setText(path); refresh_roster_list(); refresh_preview()
                    unknown = sum(1 for a in values if a not in self._people_by_agms)
                    self.store.log_admin_action("SHIFT_ROSTER_LOADED", {"file": path, "count": len(values), "unknown_in_main_personnel": unknown})
                    if unknown:
                        QMessageBox.information(dlg, "Excel βάρδιας", f"Φορτώθηκαν {len(values)} Α.Γ.Μ.Σ.\n{unknown} δεν βρέθηκαν στο κύριο αρχείο προσωπικού. Δεν αποκλείστηκαν — θα εμφανίζονται με τον Α.Γ.Μ.Σ. τους.")
                except Exception as exc:
                    QMessageBox.critical(dlg, "Excel βάρδιας", str(exc))

            def add_member():
                agms = _clean(add_agms.text())
                if not agms:
                    return
                if agms not in roster_agms:
                    roster_agms.append(agms)
                    self.store.log_admin_action("SHIFT_MEMBER_ADDED", {"agms": agms})
                add_agms.clear(); refresh_roster_list(); refresh_preview()

            def remove_member():
                row = roster_list.currentRow()
                if 0 <= row < len(roster_agms):
                    removed = roster_agms.pop(row)
                    self.store.log_admin_action("SHIFT_MEMBER_REMOVED", {"agms": removed})
                    refresh_roster_list(); refresh_preview()

            def save_shift():
                if not roster_agms:
                    QMessageBox.warning(dlg, "Έλεγχος", "Επιλέξτε πρώτα το Excel βάρδιας."); return
                data = self.store.save_shift(current_start(), roster_agms, lookback.value(), roster_path.text())
                shift_status.setText("Κατάσταση: ΠΡΟΣΩΡΙΝΗ")
                shift_status.setStyleSheet("font-weight:700;color:#8a5a16")
                QMessageBox.information(dlg, "Βάρδια", f"Αποθηκεύτηκε προσωρινά η βάρδια {data['shift_id']} με {len(data['agms'])} άτομα.")
                refresh_preview()

            def finalize_shift():
                if not roster_agms:
                    QMessageBox.warning(dlg, "Έλεγχος", "Επιλέξτε πρώτα το προσωπικό της βάρδιας."); return
                reply = QMessageBox.question(dlg, "Οριστικοποίηση", "Ελέγξατε την προεπισκόπηση; Μετά την οριστικοποίηση η συγκεκριμένη βάρδια δεν θα αντικαθίσταται.\n\nΝα οριστικοποιηθεί;", QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                if reply != QMessageBox.Yes:
                    return
                try:
                    data = self.store.save_shift(current_start(), roster_agms, lookback.value(), roster_path.text())
                    report_text = build_roster_shift_text(self.store, data, self._people_by_agms)
                    data = self.store.finalize_shift(data, report_text)
                    shift_status.setText("Κατάσταση: ΟΡΙΣΤΙΚΟΠΟΙΗΜΕΝΗ")
                    shift_status.setStyleSheet("font-weight:800;color:#1f6f50")
                    QMessageBox.information(dlg, "Βάρδια", f"Η βάρδια {data['shift_id']} οριστικοποιήθηκε.\nΤο αρχικό ιστορικό καταγραφών δεν μεταβλήθηκε.")
                except Exception as exc:
                    QMessageBox.critical(dlg, "Οριστικοποίηση", str(exc))

            choose.clicked.connect(choose_roster); add_btn.clicked.connect(add_member); remove_btn.clicked.connect(remove_member); save.clicked.connect(save_shift); finalize.clicked.connect(finalize_shift)
            dt_edit.dateTimeChanged.connect(lambda *_: refresh_preview()); lookback.valueChanged.connect(lambda *_: refresh_preview())
            refresh_preview(); dlg.exec()

        def _add_position(self):
            value, ok = QInputDialog.getText(self, "Νέα θέση", "Ονομασία / αριθμός θέσης")
            value = _clean(value)
            if ok and value:
                existing = [self.position.itemText(i) for i in range(self.position.count())]
                if value not in existing: self.position.addItem(value)
                self.position.setCurrentText(value); self._save_config()

        def _report(self):
            if not self.store:
                QMessageBox.warning(self, "Έλεγχος", "Ορίστε κεντρικό φάκελο."); return
            shifts = self.store.list_shifts()
            if not shifts:
                QMessageBox.information(self, "Αναφορές", "Δεν υπάρχουν αποθηκευμένες βάρδιες ακόμη."); return
            dlg = QDialog(self); dlg.setWindowTitle("Αναφορά βάρδιας"); dlg.resize(860,680)
            lay = QVBoxLayout(dlg)
            selector = QComboBox()
            for sh in shifts:
                dt = datetime.fromisoformat(sh["start_at"])
                status = "ΟΡΙΣΤΙΚΗ" if _clean(sh.get("status")).upper() == "FINALIZED" else "ΠΡΟΣΩΡΙΝΗ"
                selector.addItem(f"{dt:%d/%m/%Y %H:%M} — {len(sh.get('agms',[]))} άτομα — {status}", sh)
            browser = QTextBrowser(); browser.setStyleSheet("font-family:Consolas,monospace")
            export = QPushButton("Αποθήκευση εκτυπώσιμης αναφοράς HTML")
            def refresh():
                sh = selector.currentData()
                browser.setPlainText(build_roster_shift_text(self.store, sh, self._people_by_agms) if sh else "")
            def do_export():
                sh = selector.currentData()
                if not sh: return
                dt = datetime.fromisoformat(sh["start_at"])
                suggested = self.store.reports / f"ΑΝΑΦΟΡΑ_ΒΑΡΔΙΑΣ_{dt:%Y-%m-%d_%H%M}.html"
                path, _ = QFileDialog.getSaveFileName(dlg, "Αποθήκευση αναφοράς", str(suggested), "HTML (*.html)")
                if path:
                    Path(path).write_text(build_roster_shift_html(self.store, sh, self._people_by_agms), encoding="utf-8")
                    QMessageBox.information(dlg,"Αναφορά",f"Αποθηκεύτηκε:\n{path}")
            selector.currentIndexChanged.connect(lambda *_: refresh()); export.clicked.connect(do_export)
            lay.addWidget(QLabel("Επιλέξτε βάρδια")); lay.addWidget(selector); lay.addWidget(browser,1); lay.addWidget(export)
            refresh(); dlg.exec()

        def _snapshot(self):
            if not self.store:
                QMessageBox.warning(self, "Έλεγχος", "Ορίστε κεντρικό φάκελο."); return
            active = self.store.active_all()
            if not active:
                QMessageBox.information(self,"Στιγμιαία εικόνα","Δεν υπάρχουν ανοικτές θέσεις."); return
            lines = [f"{x.get('rank','')} {x.get('full_name','')} — Θ. {x.get('position','')} {x.get('direction','')} — από {x.get('timestamp','').replace('T',' ')}" for x in active]
            QMessageBox.information(self,"Στιγμιαία εικόνα","\n".join(lines))

    app = QApplication.instance() or QApplication(list(args or sys.argv))
    window = MainWindow(); window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(run())
