ΚΑΤΑΓΡΑΦΗ ΘΕΣΕΩΝ — WINDOWS RELEASE BUILDER

ΤΙ ΚΑΝΕΤΕ ΣΕ WINDOWS
1. Αποσυμπιέστε ολόκληρο τον φάκελο.
2. Διπλό κλικ στο BUILD_FINAL_WINDOWS.bat.
3. Περιμένετε μέχρι να εμφανιστεί "BUILD ΟΛΟΚΛΗΡΩΘΗΚΕ ΕΠΙΤΥΧΩΣ".
4. Το EXE θα βρίσκεται εδώ:
   RELEASE\Καταγραφή Θέσεων\Καταγραφή Θέσεων.exe
5. Θα δημιουργηθεί και πλήρες:
   POSITION_TRACKING_WINDOWS_FINAL.zip

ΣΗΜΑΝΤΙΚΟ
- Το build είναι --onedir, άρα το exe χρειάζεται τον διπλανό φάκελο _internal.
- Μην αντιγράφετε μόνο το exe. Κρατήστε ολόκληρο τον φάκελο "Καταγραφή Θέσεων".
- Ο φάκελος RELEASE περιλαμβάνει και ΠΗΓΑΙΟ ΚΩΔΙΚΑ + TEST_REPORTS.
- Αν υπάρχει αρχείο app.ico δίπλα στο BAT, χρησιμοποιείται αυτόματα ως εικονίδιο.

ΤΕΛΙΚΟΙ ΕΛΕΓΧΟΙ ΤΗΣ ΠΗΓΗΣ
- Flexible import: 14/14 PASS
- Regression/stress: PASS
- Randomized hard stress: 121/121 PASS
- Τελικό recheck: PASS

Η παραγωγική εφαρμογή δεν αντικαθίσταται πριν γίνει ένα τελευταίο άνοιγμα/START/END/ADMIN/live-map test στο πραγματικό Windows περιβάλλον.
