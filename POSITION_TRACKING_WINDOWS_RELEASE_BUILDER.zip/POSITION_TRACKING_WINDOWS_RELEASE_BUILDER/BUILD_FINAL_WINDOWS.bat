@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"

echo ============================================================
echo   Τ.Δ.Ε. ΚΡΥΣΤΑΛΛΟΠΗΓΗΣ - ΚΑΤΑΓΡΑΦΗ ΘΕΣΕΩΝ
echo   ΤΕΛΙΚΟ WINDOWS BUILD
echo ============================================================
echo.

set "PY="
where py >nul 2>&1 && set "PY=py"
if not defined PY (
  where python >nul 2>&1 && set "PY=python"
)
if not defined PY goto :nopython

echo [1/6] Ελεγχος Python...
%PY% --version
if errorlevel 1 goto :err

echo.
echo [2/6] Εγκατασταση/ελεγχος βιβλιοθηκων...
%PY% -m pip install --upgrade pip
if errorlevel 1 goto :err
%PY% -m pip install -r requirements.txt
if errorlevel 1 goto :err

echo.
echo [3/6] Ελεγχος συνταξης πηγαιου κωδικα...
%PY% -m py_compile position_tracking_FINAL.py
if errorlevel 1 goto :err

echo.
echo [4/6] Δημιουργια EXE...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist "Καταγραφή Θέσεων.spec" del /q "Καταγραφή Θέσεων.spec"

set "ICONARG="
if exist app.ico set "ICONARG=--icon app.ico"

%PY% -m PyInstaller --noconfirm --clean --windowed --onedir --name "Καταγραφή Θέσεων" %ICONARG% position_tracking_FINAL.py
if errorlevel 1 goto :err

echo.
echo [5/6] Δημιουργια φακελου παραδοσης...
if exist RELEASE rmdir /s /q RELEASE
mkdir RELEASE
xcopy /e /i /y "dist\Καταγραφή Θέσεων" "RELEASE\Καταγραφή Θέσεων" >nul
mkdir "RELEASE\ΠΗΓΑΙΟΣ ΚΩΔΙΚΑΣ"
copy /y position_tracking_FINAL.py "RELEASE\ΠΗΓΑΙΟΣ ΚΩΔΙΚΑΣ\" >nul
copy /y requirements.txt "RELEASE\ΠΗΓΑΙΟΣ ΚΩΔΙΚΑΣ\" >nul
copy /y BUILD_FINAL_WINDOWS.bat "RELEASE\ΠΗΓΑΙΟΣ ΚΩΔΙΚΑΣ\" >nul
if exist TEST_REPORTS xcopy /e /i /y TEST_REPORTS "RELEASE\TEST_REPORTS" >nul

> "RELEASE\ΔΙΑΒΑΣΕ ΜΕ.txt" echo ΚΑΤΑΓΡΑΦΗ ΘΕΣΕΩΝ - ΤΕΛΙΚΗ ΕΚΔΟΣΗ
>>"RELEASE\ΔΙΑΒΑΣΕ ΜΕ.txt" echo.
>>"RELEASE\ΔΙΑΒΑΣΕ ΜΕ.txt" echo Εκτελεσιμο: Καταγραφή Θέσεων\Καταγραφή Θέσεων.exe
>>"RELEASE\ΔΙΑΒΑΣΕ ΜΕ.txt" echo Ο πηγαιος κωδικας και τα test reports περιλαμβανονται στον ιδιο φακελο παραδοσης.
>>"RELEASE\ΔΙΑΒΑΣΕ ΜΕ.txt" echo Μην διαγραφετε τον φακελο _internal που βρισκεται διπλα στο exe.

powershell -NoProfile -Command "$p='RELEASE\Καταγραφή Θέσεων\Καταγραφή Θέσεων.exe'; if(Test-Path $p){(Get-FileHash -Algorithm SHA256 $p).Hash + '  Καταγραφή Θέσεων.exe' | Set-Content -Encoding UTF8 'RELEASE\SHA256.txt'}"

echo.
echo [6/6] Δημιουργια ZIP παραδοσης...
if exist POSITION_TRACKING_WINDOWS_FINAL.zip del /q POSITION_TRACKING_WINDOWS_FINAL.zip
powershell -NoProfile -Command "Compress-Archive -Path 'RELEASE\*' -DestinationPath 'POSITION_TRACKING_WINDOWS_FINAL.zip' -Force"
if errorlevel 1 goto :err

echo.
echo ============================================================
echo   BUILD ΟΛΟΚΛΗΡΩΘΗΚΕ ΕΠΙΤΥΧΩΣ
echo ============================================================
echo.
echo EXE:
echo   RELEASE\Καταγραφή Θέσεων\Καταγραφή Θέσεων.exe
echo.
echo ΠΛΗΡΕΣ ZIP:
echo   POSITION_TRACKING_WINDOWS_FINAL.zip
echo.
echo Δοκιμαστε πρωτα το EXE πριν αντικαταστησετε την παραγωγικη εφαρμογη.
echo.
pause
exit /b 0

:nopython
echo.
echo ΣΦΑΛΜΑ: Δεν βρεθηκε Python στα Windows.
echo Εγκαταστηστε Python 3.11 ή νεοτερη και ενεργοποιηστε το "Add Python to PATH".
pause
exit /b 2

:err
echo.
echo ============================================================
echo   BUILD FAILED
 echo ============================================================
echo Κρατηστε το μηνυμα λαθους που εμφανιζεται παραπανω.
pause
exit /b 1
